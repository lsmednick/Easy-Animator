/**
 * This is a public enum representing the various types of shapes supported by this animator.
 */

public enum ShapeType {
  RECTANGLE, OVAL, TRIANGLE
}
